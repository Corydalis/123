const styled = aElement => {
    const el = document.createElement(aElement);
    return args => {
        const styles = args[0];
        el.style = styles;
        return el;
    };
}

const title = styled("h1")`
	color: red;
  background: #333333;
 `;
 

title.innerText = "asdf";
document.body.append(title);


const styling = decoEl => {
	const yoso = document.createElement(decoEl);
  return arguments => {
  	const real_style = arguments[0];
    yoso.style = real_style;
    return yoso;
  }
}

const test = styling("h3")`
	color: orange;
  background: #123456;
  `;
  
  test.innerText = "testYeah";
  document.body.append(test);